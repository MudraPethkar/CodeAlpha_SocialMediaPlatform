import urllib.request
import urllib.parse
import json
import http.cookiejar

BASE_URL = "http://127.0.0.1:8080"
cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))

def request(path, method="GET", data=None, headers=None):
    if headers is None:
        headers = {}
    url = BASE_URL + path
    body = None
    if data is not None:
        headers["Content-Type"] = "application/json"
        body = json.dumps(data).encode("utf-8")
    
    # Extract CSRF token from cookies if available
    for cookie in cj:
        if cookie.name == "csrftoken":
            headers["X-CSRFToken"] = cookie.value

    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with opener.open(req) as resp:
            content = resp.read().decode("utf-8")
            try:
                return resp.status, json.loads(content)
            except Exception:
                return resp.status, content
    except urllib.error.HTTPError as e:
        content = e.read().decode("utf-8")
        try:
            return e.code, json.loads(content)
        except Exception:
            return e.code, content

print("=== Running End-to-End Tests for NOOK Platform ===")

# 1. Root page
status, html = request("/")
assert status == 200, f"Expected 200, got {status}"
assert "NOOK" in html, "NOOK brand not found in HTML"
print("[PASS] 1. Root HTML loads with NOOK branding")

# 2. Check Static Assets
status, css = request("/static/css/style.css")
assert status == 200, f"Expected 200, got {status}"
assert "#8B72D9" in css, "Brand color not found in CSS"
assert "#211C2B" in css, "Dark mode color not found in CSS"
print("[PASS] 2. Static CSS loaded with verified brand tokens (#8B72D9, #211C2B, etc.)")

# 3. Check guest me
status, me_guest = request("/api/auth/me/")
assert status == 200 and not me_guest.get("authenticated"), "Guest should not be authenticated"
print("[PASS] 3. Unauthenticated session check verified")

# 4. Demo Login as Maya Lin
status, login_res = request("/api/auth/demo-login/", method="POST", data={"username": "maya_reads"})
assert status == 200, f"Demo login failed: {login_res}"
assert login_res["user"]["username"] == "maya_reads", "Wrong user returned"
print(f"[PASS] 4. Demo login successful for @{login_res['user']['username']} ({login_res['user']['display_name']})")

# 5. Check authenticated me
status, me_auth = request("/api/auth/me/")
assert status == 200 and me_auth.get("authenticated"), "Session not preserved"
assert me_auth["user"]["username"] == "maya_reads"
print("[PASS] 5. Session persistence verified")

# 6. Create a new post
post_payload = {
    "content": "✨ Spending a quiet morning in the conservatory with hot coffee and gentle rain. #CozyCorners #SlowWeb",
    "image_url": "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80"
}
status, new_post = request("/api/posts/", method="POST", data=post_payload)
assert status == 201, f"Create post failed: {new_post}"
post_id = new_post["post"]["id"]
print(f"[PASS] 6. Created new post #{post_id}")

# 7. Like the post
status, like_res = request(f"/api/posts/{post_id}/like/", method="POST")
assert status == 200, f"Like failed: {like_res}"
assert like_res["is_liked"] is True, "Post should be liked"
print(f"[PASS] 7. Liked post #{post_id} (like count: {like_res['likes_count']})")

# 8. Add comment to post
comment_payload = {"content": "This brings such a tranquil feeling! Where is this spot?"}
status, comment_res = request(f"/api/posts/{post_id}/comments/", method="POST", data=comment_payload)
assert status == 201, f"Comment failed: {comment_res}"
comment_id = comment_res["comment"]["id"]
print(f"[PASS] 8. Added comment #{comment_id} to post #{post_id}")

# 9. Save/Bookmark post
status, save_res = request(f"/api/posts/{post_id}/save/", method="POST")
assert status == 200 and save_res["is_saved"] is True, f"Save failed: {save_res}"
print(f"[PASS] 9. Saved/Bookmarked post #{post_id}")

# 10. Follow toggle
status, follow_res = request("/api/users/alex_dev/follow/", method="POST")
assert status == 200, f"Follow failed: {follow_res}"
print(f"[PASS] 10. Follow action verified: {follow_res['message']}")

# 11. Profile details
status, profile = request("/api/users/maya_reads/")
assert status == 200 and profile["posts_count"] >= 3, f"Profile check failed: {profile}"
print(f"[PASS] 11. User profile API verified with posts count: {profile['posts_count']}, followers: {profile['followers_count']}")

# 12. Notifications list
status, notifs = request("/api/notifications/")
assert status == 200, f"Notifications failed: {notifs}"
print(f"[PASS] 12. Notifications API verified ({len(notifs['results'])} notifications)")

# 13. Feed filtering
status, feed_data = request("/api/posts/?feed=for_you")
assert status == 200 and feed_data["count"] > 0
print(f"[PASS] 13. Reverse-chronological feed verified ({feed_data['count']} total posts)")

print("\n[SUCCESS] ALL 13 END-TO-END AUTOMATED VERIFICATION TESTS PASSED SUCCESSFULLY!")
