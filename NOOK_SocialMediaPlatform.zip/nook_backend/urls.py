from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from nook_app.views import index

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('nook_app.urls')),
    path('', index, name='index'),
    # Catch-all for SPA client-side routes (e.g. /profile, /explore, /notifications, /settings, /post/:id)
    re_path(r'^(?!api/|admin/|static/|media/).*$', index, name='spa_fallback'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
