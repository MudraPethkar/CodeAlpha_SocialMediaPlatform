# 🌿 NOOK — A Cozy & Mindful Social Media Platform

**NOOK** is a clean, modern, mobile-friendly full-stack social media application designed for mindful sharing, warm community interactions, and creative expression.

Users can create customizable profiles, publish rich posts (text and images), like content with interactive heart animations, leave comments, follow/unfollow creators, bookmark posts, receive real-time notifications, and toggle seamlessly between Airy Lilac Light Mode and Midnight Plum Dark Mode.

---

## 🎨 Brand Identity & Color Palette

The interface is built around a warm, cozy aesthetic with rounded surfaces, soft shadows, and clear typography (*Plus Jakarta Sans*):

| Element / Interaction | Exact Hex Code | Usage in App |
|---|---|---|
| **Primary Brand / Primary CTA** | `#8B72D9` | Brand logo, **Post**, **Follow**, **Sign Up**, active icons |
| **Active Navigation Icons** | `#8B72D9` | Sidebar and mobile bottom navigation active indicators |
| **Like / Love Interactions** | `#D56A91` | Liked heart state, bounce animation, like counter |
| **Success & Positive Status** | `#A8CDB5` | Success toasts ("Posted!", "Saved to bookmarks") |
| **Stories & Highlights** | `#F4D9A6` | Story rings, highlight accents, official creator badges |
| **Main Feed Background (Light)** | `#FAF8FF` | Feed background in light mode |
| **Dark Mode Background** | `#211C2B` | Full dark mode background with high-contrast text |

---

## 🛠️ Tech Stack & Architecture

- **Frontend:** Semantic HTML5, Vanilla CSS (CSS variables, responsive CSS Grid / Flexbox, micro-animations), and Vanilla JavaScript (SPA architecture with asynchronous Fetch API & CSRF token exchange).
- **Backend:** Django 5 with Django REST Framework (DRF) and CORS headers.
- **Database:** SQLite (default for development; compatible with PostgreSQL).
- **Authentication:** Django standard password hashing (PBKDF2/SHA256) and secure session management.
- **Media Handling:** File uploads and external media URL rendering with lightbox zoom.

---

## 🗄️ Database Models & Schema

All user-generated content is stored persistently in the database:

1. **User** (`nook_app.User` extending `AbstractUser`):
   - `id`, `username` (unique), `email` (unique), `password` (hashed), `display_name`, `bio`, `avatar` (ImageField), `avatar_url`, `cover_image`, `created_at`.
2. **Post** (`nook_app.Post`):
   - `id`, `author` (FK User), `content` (TextField), `image` (ImageField), `image_url` (URLField), `created_at`, `updated_at`.
3. **Comment** (`nook_app.Comment`):
   - `id`, `post` (FK Post), `author` (FK User), `content` (TextField), `created_at`.
4. **Like** (`nook_app.Like`):
   - `id`, `user` (FK User), `post` (FK Post), `created_at`.
   - **Unique Constraint:** `('user', 'post')` to prevent duplicate likes.
5. **Follow** (`nook_app.Follow`):
   - `id`, `follower` (FK User), `following` (FK User), `created_at`.
   - **Unique Constraint:** `('follower', 'following')` to prevent duplicate follows.
6. **SavedPost** (`nook_app.SavedPost`):
   - `id`, `user` (FK User), `post` (FK Post), `created_at`.
   - **Unique Constraint:** `('user', 'post')` for bookmarking posts.
7. **Notification** (`nook_app.Notification`):
   - `id`, `recipient` (FK User), `actor` (FK User), `type` ('like', 'comment', 'follow'), `post` (FK Post nullable), `comment` (FK Comment nullable), `is_read` (BooleanField), `created_at`.

---

## 🚀 Getting Started Locally

### 1. Prerequisites
- Python 3.10+
- `pip`

### 2. Install Dependencies
```bash
python -m pip install -r requirements.txt
```

### 3. Run Database Migrations
```bash
python manage.py makemigrations nook_app
python manage.py migrate
```

### 4. Seed the Database with Realistic Demo Data
Populates the database with realistic demo users, profile avatars, curated posts, comments, likes, and follows:
```bash
python manage.py seed_data
```

### 5. Start the Server
```bash
python manage.py runserver 127.0.0.1:8080
```
Open **[http://127.0.0.1:8080/](http://127.0.0.1:8080/)** in your browser.

---

## 👥 Demo Accounts for Immediate Testing

Use the **1-Click Demo Buttons** in the app header or right sidebar, or log in manually with password `nook123`:

| Username | Name | Bio / Persona |
|---|---|---|
| `maya_reads` | Maya Lin | Cozy reader, specialty coffee lover & morning thinker |
| `leo_creates` | Leo Vance | Digital product designer, photographer & UI creator |
| `chloe_bakes` | Chloe Martin | Artisan sourdough baker & pastry chef in Portland |
| `alex_dev` | Alex Rivers | Full-stack developer building open-source tools |
| `admin` | Admin Nook | Superuser (password: `admin123`) for Django Admin at `/admin/` |

---

## 📡 RESTful API Endpoints

### Authentication
- `POST /api/auth/register/` — Register a new account (`username`, `email`, `password`, `display_name`, `bio`)
- `POST /api/auth/login/` — Log in with username/email and password
- `POST /api/auth/demo-login/` — 1-click login for demo accounts
- `POST /api/auth/logout/` — End the current user session
- `GET /api/auth/me/` — Retrieve current authenticated user profile & unread notification counter

### User Profiles & Follows
- `GET /api/users/<username>/` — View user public profile, follower/following/post counts
- `PATCH /api/users/me/` — Update profile display name, bio, and avatar
- `POST /api/users/<username>/follow/` — Toggle follow/unfollow on a user
- `GET /api/users/<username>/followers/` — Retrieve list of followers
- `GET /api/users/<username>/following/` — Retrieve list of followed users
- `GET /api/users/suggested/` — Retrieve suggested accounts to follow

### Posts & Feeds
- `GET /api/posts/` — List posts with pagination (`?feed=for_you`, `?feed=following`, `?author=<username>`, `?saved=true`, `?liked=true`, `?search=<query>`)
- `POST /api/posts/` — Create a new post with text content and optional image
- `GET /api/posts/<id>/` — Post detail with full threaded comments
- `PATCH /api/posts/<id>/` — Edit own post content
- `DELETE /api/posts/<id>/` — Delete own post
- `POST /api/posts/<id>/like/` — Toggle like/unlike with immediate count update
- `POST /api/posts/<id>/save/` — Bookmark or unbookmark a post
- `GET /api/posts/<id>/comments/` — Retrieve all comments for a post
- `POST /api/posts/<id>/comments/` — Add a comment to a post
- `DELETE /api/comments/<id>/` — Delete a comment (by comment author or post author)

### Notifications & Settings
- `GET /api/notifications/` — List recent notifications with actor info
- `POST /api/notifications/mark-read/` — Mark notification(s) as read
- `POST /api/settings/password/` — Change user password securely

---

## 🔒 Security & Quality Assurances

1. **CSRF Protection:** Django's CSRF token protection enabled; `api.js` extracts and sends `X-CSRFToken` header.
2. **XSS Protection:** Content and comments are sanitized using `escapeHtml()` in frontend rendering.
3. **Database Constraints:** Unique database constraints ensure no duplicate likes, follows, or saved posts.
4. **Authorization Checks:** Only the author of a post or comment can edit or delete their content.
5. **Session Security:** Passwords hashed with PBKDF2 with SHA-256; sessions stored securely on the backend.
6. **Automated Verification:** Verified with `test_suite.py` passing all 13 end-to-end integration tests.
