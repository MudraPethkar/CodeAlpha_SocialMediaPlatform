from django.urls import path
from . import views

urlpatterns = [
    # Auth endpoints
    path('auth/register/', views.api_register, name='api_register'),
    path('auth/login/', views.api_login, name='api_login'),
    path('auth/demo-login/', views.api_demo_login, name='api_demo_login'),
    path('auth/logout/', views.api_logout, name='api_logout'),
    path('auth/me/', views.api_auth_me, name='api_auth_me'),

    # User profile & relationships
    path('users/me/', views.api_update_me, name='api_update_me'),
    path('users/suggested/', views.api_suggested_users, name='api_suggested_users'),
    path('users/<str:username>/', views.api_user_profile, name='api_user_profile'),
    path('users/<str:username>/follow/', views.api_toggle_follow, name='api_toggle_follow'),
    path('users/<str:username>/followers/', views.api_user_followers, name='api_user_followers'),
    path('users/<str:username>/following/', views.api_user_following, name='api_user_following'),

    # Posts & feeds
    path('posts/', views.api_posts_list_create, name='api_posts_list_create'),
    path('posts/<int:post_id>/', views.api_post_detail, name='api_post_detail'),
    path('posts/<int:post_id>/like/', views.api_toggle_like, name='api_toggle_like'),
    path('posts/<int:post_id>/save/', views.api_toggle_save, name='api_toggle_save'),
    path('posts/<int:post_id>/comments/', views.api_post_comments, name='api_post_comments'),
    path('comments/<int:comment_id>/', views.api_delete_comment, name='api_delete_comment'),

    # Notifications
    path('notifications/', views.api_notifications_list, name='api_notifications_list'),
    path('notifications/mark-read/', views.api_mark_notifications_read, name='api_mark_notifications_read'),

    # Settings
    path('settings/password/', views.api_change_password, name='api_change_password'),
]
