from django.apps import AppConfig


class NookAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nook_app'
