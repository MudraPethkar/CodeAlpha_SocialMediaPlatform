from rest_framework import serializers
from .models import User, Post, Comment, Like, Follow, SavedPost, Notification


class MiniUserSerializer(serializers.ModelSerializer):
    avatar_url = serializers.SerializerMethodField()
    display_name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'display_name', 'avatar_url', 'bio']

    def get_avatar_url(self, obj):
        return obj.get_avatar_url()

    def get_display_name(self, obj):
        return obj.get_display_name()


class UserProfileSerializer(serializers.ModelSerializer):
    avatar_url = serializers.SerializerMethodField()
    display_name = serializers.SerializerMethodField()
    posts_count = serializers.SerializerMethodField()
    followers_count = serializers.SerializerMethodField()
    following_count = serializers.SerializerMethodField()
    is_following = serializers.SerializerMethodField()
    is_self = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'display_name', 'bio',
            'avatar_url', 'created_at', 'posts_count',
            'followers_count', 'following_count', 'is_following', 'is_self'
        ]

    def get_avatar_url(self, obj):
        return obj.get_avatar_url()

    def get_display_name(self, obj):
        return obj.get_display_name()

    def get_posts_count(self, obj):
        return obj.posts.count()

    def get_followers_count(self, obj):
        return obj.follower_relations.count()

    def get_following_count(self, obj):
        return obj.following_relations.count()

    def get_is_following(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated or request.user == obj:
            return False
        return Follow.objects.filter(follower=request.user, following=obj).exists()

    def get_is_self(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return request.user == obj


class CommentSerializer(serializers.ModelSerializer):
    author = MiniUserSerializer(read_only=True)
    is_author = serializers.SerializerMethodField()

    class Meta:
        model = Comment
        fields = ['id', 'post_id', 'author', 'content', 'created_at', 'is_author']
        read_only_fields = ['id', 'author', 'created_at']

    def get_is_author(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return request.user == obj.author or request.user == obj.post.author


class PostSerializer(serializers.ModelSerializer):
    author = MiniUserSerializer(read_only=True)
    image_url = serializers.SerializerMethodField()
    likes_count = serializers.SerializerMethodField()
    comments_count = serializers.SerializerMethodField()
    is_liked = serializers.SerializerMethodField()
    is_saved = serializers.SerializerMethodField()
    is_author = serializers.SerializerMethodField()
    recent_comments = serializers.SerializerMethodField()

    class Meta:
        model = Post
        fields = [
            'id', 'author', 'content', 'image_url', 'created_at', 'updated_at',
            'likes_count', 'comments_count', 'is_liked', 'is_saved', 'is_author',
            'recent_comments'
        ]
        read_only_fields = ['id', 'author', 'created_at', 'updated_at']

    def get_image_url(self, obj):
        return obj.get_image_url()

    def get_likes_count(self, obj):
        return obj.likes.count()

    def get_comments_count(self, obj):
        return obj.comments.count()

    def get_is_liked(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return Like.objects.filter(user=request.user, post=obj).exists()

    def get_is_saved(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return SavedPost.objects.filter(user=request.user, post=obj).exists()

    def get_is_author(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return request.user == obj.author

    def get_recent_comments(self, obj):
        # Get up to 3 recent comments for quick in-feed preview
        comments = obj.comments.select_related('author').order_by('-created_at')[:3]
        return CommentSerializer(reversed(comments), many=True, context=self.context).data


class NotificationSerializer(serializers.ModelSerializer):
    actor = MiniUserSerializer(read_only=True)
    post_id = serializers.SerializerMethodField()
    post_preview = serializers.SerializerMethodField()

    class Meta:
        model = Notification
        fields = ['id', 'actor', 'type', 'post_id', 'post_preview', 'is_read', 'created_at']

    def get_post_id(self, obj):
        return obj.post.id if obj.post else None

    def get_post_preview(self, obj):
        if obj.post:
            preview = obj.post.content[:60]
            if len(obj.post.content) > 60:
                preview += "..."
            return preview
        return None
