import json
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_exempt
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.core.paginator import Paginator

from .models import User, Post, Comment, Like, Follow, SavedPost, Notification
from .serializers import (
    UserProfileSerializer, MiniUserSerializer,
    PostSerializer, CommentSerializer, NotificationSerializer
)


@ensure_csrf_cookie
def index(request):
    """Renders the single-page application and sets CSRF cookie."""
    return render(request, 'index.html')


# ==========================================
# AUTH VIEWS
# ==========================================

@csrf_exempt
def api_register(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        data = request.POST

    username = data.get('username', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '')
    display_name = data.get('display_name', '').strip()
    bio = data.get('bio', '').strip()

    if not username:
        return JsonResponse({'error': 'Username is required.'}, status=400)
    if len(username) < 3:
        return JsonResponse({'error': 'Username must be at least 3 characters.'}, status=400)
    if not email:
        return JsonResponse({'error': 'Email is required.'}, status=400)
    if not password or len(password) < 6:
        return JsonResponse({'error': 'Password must be at least 6 characters.'}, status=400)

    if User.objects.filter(username__iexact=username).exists():
        return JsonResponse({'error': 'Username is already taken.'}, status=400)
    if User.objects.filter(email__iexact=email).exists():
        return JsonResponse({'error': 'An account with this email already exists.'}, status=400)

    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
        display_name=display_name or username.capitalize(),
        bio=bio
    )
    login(request, user)
    serializer = UserProfileSerializer(user, context={'request': request})
    return JsonResponse({'message': 'Registration successful!', 'user': serializer.data}, status=201)


@csrf_exempt
def api_login(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        data = request.POST

    identifier = data.get('username_or_email', '').strip()
    password = data.get('password', '')

    if not identifier or not password:
        return JsonResponse({'error': 'Username/email and password are required.'}, status=400)

    user = None
    if '@' in identifier:
        try:
            target_user = User.objects.get(email__iexact=identifier)
            user = authenticate(username=target_user.username, password=password)
        except User.DoesNotExist:
            user = None
    else:
        user = authenticate(username=identifier, password=password)

    if user is not None:
        if not user.is_active:
            return JsonResponse({'error': 'This account has been disabled.'}, status=403)
        login(request, user)
        serializer = UserProfileSerializer(user, context={'request': request})
        return JsonResponse({'message': 'Welcome back!', 'user': serializer.data})
    else:
        return JsonResponse({'error': 'Invalid username/email or password.'}, status=401)


@csrf_exempt
def api_demo_login(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        data = request.POST

    username = data.get('username', 'maya_reads')
    try:
        user = User.objects.get(username=username)
    except User.DoesNotExist:
        # fallback to first user
        user = User.objects.first()
        if not user:
            return JsonResponse({'error': 'No demo user found in database.'}, status=404)

    login(request, user)
    serializer = UserProfileSerializer(user, context={'request': request})
    return JsonResponse({'message': f'Logged in as demo user @{user.username}', 'user': serializer.data})


@csrf_exempt
def api_logout(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    logout(request)
    return JsonResponse({'message': 'Logged out successfully.'})


def api_auth_me(request):
    if not request.user.is_authenticated:
        return JsonResponse({'authenticated': False, 'user': None})
    serializer = UserProfileSerializer(request.user, context={'request': request})
    unread_notifications = Notification.objects.filter(recipient=request.user, is_read=False).count()
    return JsonResponse({
        'authenticated': True,
        'user': serializer.data,
        'unread_notifications': unread_notifications
    })


# ==========================================
# USER & PROFILE VIEWS
# ==========================================

def api_user_profile(request, username):
    user = get_object_or_404(User, username__iexact=username)
    serializer = UserProfileSerializer(user, context={'request': request})
    return JsonResponse(serializer.data)


@csrf_exempt
def api_update_me(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required.'}, status=401)

    user = request.user
    if request.method == 'POST' or request.method == 'PATCH':
        display_name = request.POST.get('display_name')
        bio = request.POST.get('bio')
        avatar_url = request.POST.get('avatar_url')

        if request.content_type and 'application/json' in request.content_type:
            try:
                body_data = json.loads(request.body.decode('utf-8'))
                display_name = body_data.get('display_name', display_name)
                bio = body_data.get('bio', bio)
                avatar_url = body_data.get('avatar_url', avatar_url)
            except Exception:
                pass

        if display_name is not None:
            user.display_name = display_name.strip()
        if bio is not None:
            user.bio = bio.strip()
        if avatar_url is not None:
            user.avatar_url = avatar_url.strip()

        if 'avatar' in request.FILES:
            user.avatar = request.FILES['avatar']

        user.save()
        serializer = UserProfileSerializer(user, context={'request': request})
        return JsonResponse({'message': 'Profile updated successfully!', 'user': serializer.data})

    return JsonResponse({'error': 'Method not allowed'}, status=405)


@csrf_exempt
def api_toggle_follow(request, username):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required.'}, status=401)

    target_user = get_object_or_404(User, username__iexact=username)
    if target_user == request.user:
        return JsonResponse({'error': 'You cannot follow yourself.'}, status=400)

    existing = Follow.objects.filter(follower=request.user, following=target_user)
    if existing.exists():
        existing.delete()
        is_following = False
        message = f'Unfollowed @{target_user.username}'
    else:
        Follow.objects.create(follower=request.user, following=target_user)
        is_following = True
        message = f'Now following @{target_user.username}'
        # Create notification
        Notification.objects.create(
            recipient=target_user,
            actor=request.user,
            type='follow'
        )

    followers_count = target_user.follower_relations.count()
    return JsonResponse({
        'is_following': is_following,
        'followers_count': followers_count,
        'message': message
    })


def api_user_followers(request, username):
    target_user = get_object_or_404(User, username__iexact=username)
    followers = [rel.follower for rel in target_user.follower_relations.select_related('follower').all()]
    serializer = MiniUserSerializer(followers, many=True)
    return JsonResponse({'results': serializer.data})


def api_user_following(request, username):
    target_user = get_object_or_404(User, username__iexact=username)
    following = [rel.following for rel in target_user.following_relations.select_related('following').all()]
    serializer = MiniUserSerializer(following, many=True)
    return JsonResponse({'results': serializer.data})


def api_suggested_users(request):
    current_user = request.user if request.user.is_authenticated else None
    queryset = User.objects.all()

    if current_user:
        following_ids = current_user.following_relations.values_list('following_id', flat=True)
        queryset = queryset.exclude(id=current_user.id).exclude(id__in=following_ids)

    # limit to 6 suggested users
    suggested = queryset.order_by('-created_at')[:6]
    serializer = MiniUserSerializer(suggested, many=True)
    return JsonResponse({'results': serializer.data})


# ==========================================
# POSTS VIEWS
# ==========================================

@csrf_exempt
def api_posts_list_create(request):
    if request.method == 'GET':
        feed_type = request.GET.get('feed', 'for_you')
        author_username = request.GET.get('author')
        saved_filter = request.GET.get('saved')
        liked_filter = request.GET.get('liked')
        search_query = request.GET.get('search', '').strip()
        page_number = int(request.GET.get('page', 1))
        page_size = int(request.GET.get('page_size', 10))

        posts = Post.objects.select_related('author').prefetch_related('comments', 'likes')

        if author_username:
            posts = posts.filter(author__username__iexact=author_username)
        elif saved_filter == 'true':
            if not request.user.is_authenticated:
                return JsonResponse({'error': 'Authentication required for saved posts.'}, status=401)
            saved_post_ids = SavedPost.objects.filter(user=request.user).values_list('post_id', flat=True)
            posts = posts.filter(id__in=saved_post_ids)
        elif liked_filter == 'true':
            if not request.user.is_authenticated:
                return JsonResponse({'error': 'Authentication required for liked posts.'}, status=401)
            liked_post_ids = Like.objects.filter(user=request.user).values_list('post_id', flat=True)
            posts = posts.filter(id__in=liked_post_ids)
        elif feed_type == 'following':
            if not request.user.is_authenticated:
                return JsonResponse({'error': 'Please log in to view followed posts.'}, status=401)
            following_ids = request.user.following_relations.values_list('following_id', flat=True)
            posts = posts.filter(author_id__in=following_ids)

        if search_query:
            posts = posts.filter(
                Q(content__icontains=search_query) |
                Q(author__username__icontains=search_query) |
                Q(author__display_name__icontains=search_query)
            )

        paginator = Paginator(posts, page_size)
        page_obj = paginator.get_page(page_number)

        serializer = PostSerializer(page_obj, many=True, context={'request': request})
        return JsonResponse({
            'results': serializer.data,
            'count': paginator.count,
            'num_pages': paginator.num_pages,
            'current_page': page_obj.number,
            'has_next': page_obj.has_next(),
            'has_previous': page_obj.has_previous(),
        })

    elif request.method == 'POST':
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required to publish a post.'}, status=401)

        content = request.POST.get('content', '')
        image_url = request.POST.get('image_url', '').strip()

        if request.content_type and 'application/json' in request.content_type:
            try:
                body_data = json.loads(request.body.decode('utf-8'))
                content = body_data.get('content', content)
                image_url = body_data.get('image_url', image_url)
            except Exception:
                pass

        content = content.strip()
        uploaded_image = request.FILES.get('image')

        if not content and not uploaded_image and not image_url:
            return JsonResponse({'error': 'Post content or image is required.'}, status=400)

        post = Post.objects.create(
            author=request.user,
            content=content,
            image=uploaded_image,
            image_url=image_url
        )

        serializer = PostSerializer(post, context={'request': request})
        return JsonResponse({'message': 'Post created successfully!', 'post': serializer.data}, status=201)

    return JsonResponse({'error': 'Method not allowed'}, status=405)


@csrf_exempt
def api_post_detail(request, post_id):
    post = get_object_or_404(Post.objects.select_related('author'), id=post_id)

    if request.method == 'GET':
        serializer = PostSerializer(post, context={'request': request})
        comments = post.comments.select_related('author').order_by('created_at')
        comments_serializer = CommentSerializer(comments, many=True, context={'request': request})
        data = serializer.data
        data['comments'] = comments_serializer.data
        return JsonResponse(data)

    elif request.method == 'PATCH':
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required.'}, status=401)
        if post.author != request.user:
            return JsonResponse({'error': 'You can only edit your own posts.'}, status=403)

        try:
            body_data = json.loads(request.body.decode('utf-8'))
        except Exception:
            body_data = request.POST

        content = body_data.get('content', '').strip()
        if not content:
            return JsonResponse({'error': 'Post content cannot be empty.'}, status=400)

        post.content = content
        post.save()
        serializer = PostSerializer(post, context={'request': request})
        return JsonResponse({'message': 'Post updated!', 'post': serializer.data})

    elif request.method == 'DELETE':
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required.'}, status=401)
        if post.author != request.user:
            return JsonResponse({'error': 'You can only delete your own posts.'}, status=403)

        post.delete()
        return JsonResponse({'message': 'Post deleted successfully.'})

    return JsonResponse({'error': 'Method not allowed'}, status=405)


@csrf_exempt
def api_toggle_like(request, post_id):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required to like posts.'}, status=401)

    post = get_object_or_404(Post, id=post_id)
    like_obj = Like.objects.filter(user=request.user, post=post)

    if like_obj.exists():
        like_obj.delete()
        is_liked = False
    else:
        Like.objects.create(user=request.user, post=post)
        is_liked = True
        # Notify post author if not self
        if post.author != request.user:
            Notification.objects.create(
                recipient=post.author,
                actor=request.user,
                type='like',
                post=post
            )

    likes_count = post.likes.count()
    return JsonResponse({
        'is_liked': is_liked,
        'likes_count': likes_count,
        'message': 'Post liked' if is_liked else 'Post unliked'
    })


@csrf_exempt
def api_toggle_save(request, post_id):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required to save posts.'}, status=401)

    post = get_object_or_404(Post, id=post_id)
    saved_obj = SavedPost.objects.filter(user=request.user, post=post)

    if saved_obj.exists():
        saved_obj.delete()
        is_saved = False
        msg = 'Removed from bookmarks'
    else:
        SavedPost.objects.create(user=request.user, post=post)
        is_saved = True
        msg = 'Saved to bookmarks'

    return JsonResponse({'is_saved': is_saved, 'message': msg})


@csrf_exempt
def api_post_comments(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    if request.method == 'GET':
        comments = post.comments.select_related('author').order_by('created_at')
        serializer = CommentSerializer(comments, many=True, context={'request': request})
        return JsonResponse({'results': serializer.data})

    elif request.method == 'POST':
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required to comment.'}, status=401)

        try:
            body_data = json.loads(request.body.decode('utf-8'))
        except Exception:
            body_data = request.POST

        content = body_data.get('content', '').strip()
        if not content:
            return JsonResponse({'error': 'Comment content cannot be empty.'}, status=400)

        comment = Comment.objects.create(
            post=post,
            author=request.user,
            content=content
        )

        # Notify post author if not self
        if post.author != request.user:
            Notification.objects.create(
                recipient=post.author,
                actor=request.user,
                type='comment',
                post=post,
                comment=comment
            )

        serializer = CommentSerializer(comment, context={'request': request})
        return JsonResponse({
            'message': 'Comment added!',
            'comment': serializer.data,
            'comments_count': post.comments.count()
        }, status=201)

    return JsonResponse({'error': 'Method not allowed'}, status=405)


@csrf_exempt
def api_delete_comment(request, comment_id):
    if request.method != 'DELETE':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required.'}, status=401)

    comment = get_object_or_404(Comment.objects.select_related('post'), id=comment_id)
    if comment.author != request.user and comment.post.author != request.user:
        return JsonResponse({'error': 'You are not authorized to delete this comment.'}, status=403)

    post_id = comment.post.id
    comment.delete()
    post = Post.objects.get(id=post_id)

    return JsonResponse({
        'message': 'Comment deleted successfully.',
        'comments_count': post.comments.count()
    })


# ==========================================
# NOTIFICATIONS VIEWS
# ==========================================

def api_notifications_list(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required.'}, status=401)

    notifications = Notification.objects.filter(recipient=request.user).select_related('actor', 'post')
    serializer = NotificationSerializer(notifications[:50], many=True)
    unread_count = notifications.filter(is_read=False).count()

    return JsonResponse({
        'results': serializer.data,
        'unread_count': unread_count
    })


@csrf_exempt
def api_mark_notifications_read(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required.'}, status=401)

    try:
        body_data = json.loads(request.body.decode('utf-8'))
    except Exception:
        body_data = request.POST

    notif_id = body_data.get('notification_id')
    if notif_id:
        Notification.objects.filter(id=notif_id, recipient=request.user).update(is_read=True)
    else:
        Notification.objects.filter(recipient=request.user, is_read=False).update(is_read=True)

    return JsonResponse({'message': 'Notifications marked as read.'})


# ==========================================
# SETTINGS VIEWS
# ==========================================

@csrf_exempt
def api_change_password(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required.'}, status=401)

    try:
        body_data = json.loads(request.body.decode('utf-8'))
    except Exception:
        body_data = request.POST

    old_password = body_data.get('old_password', '')
    new_password = body_data.get('new_password', '')

    if not request.user.check_password(old_password):
        return JsonResponse({'error': 'Current password is incorrect.'}, status=400)

    if len(new_password) < 6:
        return JsonResponse({'error': 'New password must be at least 6 characters.'}, status=400)

    request.user.set_password(new_password)
    request.user.save()
    login(request, request.user)  # Keep logged in after password change
    return JsonResponse({'message': 'Password changed successfully.'})
