from django.core.management.base import BaseCommand
from nook_app.models import User, Post, Comment, Like, Follow, SavedPost, Notification


class Command(BaseCommand):
    help = 'Seeds database with realistic demo users, posts, comments, likes, and follows for NOOK.'

    def handle(self, *args, **kwargs):
        self.stdout.write(self.style.NOTICE('Seeding NOOK database...'))

        # Demo Users
        users_data = [
            {
                'username': 'maya_reads',
                'email': 'maya@nook.app',
                'display_name': 'Maya Lin',
                'bio': '☕ Cozy reader, specialty coffee geek & quiet morning thinker. Sharing book reviews, aesthetic corners, and warm playlists.',
                'avatar_url': 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
            },
            {
                'username': 'leo_creates',
                'email': 'leo@nook.app',
                'display_name': 'Leo Vance',
                'bio': '✨ Digital product designer & visual storyteller. Exploring soft lighting, glassmorphism, and minimal setups.',
                'avatar_url': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
            },
            {
                'username': 'chloe_bakes',
                'email': 'chloe@nook.app',
                'display_name': 'Chloe Martin',
                'bio': '🥐 Artisan sourdough baker & pastry enthusiast. Flour, butter, and patience. Studio in Portland.',
                'avatar_url': 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80',
            },
            {
                'username': 'alex_dev',
                'email': 'alex@nook.app',
                'display_name': 'Alex Rivers',
                'bio': '⚡ Full-stack dev building warm web experiences. Writing code by day, reading speculative fiction by night.',
                'avatar_url': 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
            },
            {
                'username': 'nook_team',
                'email': 'hello@nook.app',
                'display_name': 'NOOK Official',
                'bio': '🌿 Welcome to NOOK! A calm, thoughtful social sanctuary designed for genuine creativity, sharing ideas, and slow community.',
                'avatar_url': 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=300&q=80',
            },
        ]

        created_users = {}
        for u in users_data:
            user, created = User.objects.get_or_create(username=u['username'], defaults={
                'email': u['email'],
                'display_name': u['display_name'],
                'bio': u['bio'],
                'avatar_url': u['avatar_url'],
            })
            if created or not user.check_password('nook123'):
                user.set_password('nook123')
                user.display_name = u['display_name']
                user.bio = u['bio']
                user.avatar_url = u['avatar_url']
                user.save()
            created_users[u['username']] = user

        # Follow relationships
        follow_pairs = [
            ('maya_reads', 'leo_creates'),
            ('maya_reads', 'chloe_bakes'),
            ('maya_reads', 'nook_team'),
            ('leo_creates', 'maya_reads'),
            ('leo_creates', 'alex_dev'),
            ('chloe_bakes', 'maya_reads'),
            ('chloe_bakes', 'nook_team'),
            ('alex_dev', 'maya_reads'),
            ('alex_dev', 'leo_creates'),
            ('alex_dev', 'chloe_bakes'),
        ]

        for follower_uname, following_uname in follow_pairs:
            f_user = created_users[follower_uname]
            t_user = created_users[following_uname]
            Follow.objects.get_or_create(follower=f_user, following=t_user)

        # Demo Posts
        posts_data = [
            {
                'author': 'nook_team',
                'content': "🌿 Welcome to your new cozy corner on the web! At NOOK, we believe social media can be calm, inspiring, and delightfully humane. Create your first post, explore topics, share moments with friends, and enjoy the cozy atmosphere. #WelcomeToNook #SlowWeb",
                'image_url': 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'author': 'maya_reads',
                'content': "Rainy afternoon essentials: an oat milk lavender latte, wool blanket, and 100 pages of Japanese contemporary fiction. What is everyone currently reading? Drop your book recommendations below! ☕📖🌧️",
                'image_url': 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'author': 'leo_creates',
                'content': "Fresh workspace iteration! Clean wood, warm 2700K ambient backlighting, and zero clutter on the desk. Mindset follows environment every single time. ✨🖥️",
                'image_url': 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'author': 'chloe_bakes',
                'content': "Fresh out of the deck oven: country sourdough batards fermented for 36 hours. That blistered mahogany crust sound is pure music! 🍞🥖 Golden hour in the bakery is unmatched.",
                'image_url': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'author': 'alex_dev',
                'content': "Weekend project: rebuilt my personal website with clean vanilla CSS tokens and semantic HTML. No 50MB node_modules bundle, loads in 60ms worldwide. Sometimes simple is the ultimate sophisticated design. 🚀",
                'image_url': 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'author': 'maya_reads',
                'content': "Found this secret garden greenhouse hidden behind the botanical library. A whole sanctuary of ferns and warm sunbeams. Definitely coming here every Sunday morning. 🪴🌿✨",
                'image_url': 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'author': 'leo_creates',
                'content': "Experimenting with pastel violet `#8B72D9` and rose tones `#D56A91` for our new brand palette. Loving the warmth and calmness it brings to screen time. What do you think?",
                'image_url': '',
            },
        ]

        created_posts = []
        for p in posts_data:
            post, created = Post.objects.get_or_create(
                author=created_users[p['author']],
                content=p['content'],
                defaults={'image_url': p['image_url']}
            )
            created_posts.append(post)

        # Comments
        comments_data = [
            (created_posts[1], 'leo_creates', 'The lavender latte setup is an absolute mood! Adding that book to my Goodreads right now 📚'),
            (created_posts[1], 'chloe_bakes', 'I recommend "Sweet Bean Paste" by Durian Sukegawa! Gentle, heartwarming, and full of culinary magic.'),
            (created_posts[2], 'alex_dev', 'That monitor lightbar makes such a difference for evening coding sessions. Solid setup!'),
            (created_posts[3], 'maya_reads', 'That blistered crust is perfection Chloe! Do you do local deliveries on weekends? 😍'),
            (created_posts[4], 'leo_creates', 'Vanilla CSS modern features (CSS variables, nesting, grid) make heavyweight libraries almost obsolete for neat apps.'),
            (created_posts[0], 'alex_dev', 'So excited to be here! The interface feels so refreshing and gentle on the eyes.'),
        ]

        for post, author_uname, text in comments_data:
            Comment.objects.get_or_create(
                post=post,
                author=created_users[author_uname],
                content=text
            )

        # Likes
        likes_data = [
            ('leo_creates', created_posts[1]),
            ('chloe_bakes', created_posts[1]),
            ('alex_dev', created_posts[1]),
            ('maya_reads', created_posts[2]),
            ('alex_dev', created_posts[2]),
            ('maya_reads', created_posts[3]),
            ('leo_creates', created_posts[3]),
            ('maya_reads', created_posts[0]),
            ('leo_creates', created_posts[0]),
            ('chloe_bakes', created_posts[0]),
            ('alex_dev', created_posts[0]),
            ('chloe_bakes', created_posts[4]),
            ('maya_reads', created_posts[4]),
        ]

        for uname, post in likes_data:
            Like.objects.get_or_create(user=created_users[uname], post=post)

        # Saved Posts for maya_reads
        SavedPost.objects.get_or_create(user=created_users['maya_reads'], post=created_posts[3])
        SavedPost.objects.get_or_create(user=created_users['maya_reads'], post=created_posts[2])

        # Notifications for maya_reads
        Notification.objects.get_or_create(
            recipient=created_users['maya_reads'],
            actor=created_users['leo_creates'],
            type='like',
            post=created_posts[1]
        )
        Notification.objects.get_or_create(
            recipient=created_users['maya_reads'],
            actor=created_users['chloe_bakes'],
            type='comment',
            post=created_posts[1]
        )
        Notification.objects.get_or_create(
            recipient=created_users['maya_reads'],
            actor=created_users['alex_dev'],
            type='follow'
        )

        self.stdout.write(self.style.SUCCESS('Successfully seeded NOOK database!'))
