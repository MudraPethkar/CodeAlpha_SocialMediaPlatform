/**
 * NOOK Social Media Platform - API Client
 * Modular, clean async API communications with CSRF handling.
 */

function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === (name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

const API = {
  async request(endpoint, options = {}) {
    const headers = options.headers || {};
    const csrfToken = getCookie('csrftoken');
    if (csrfToken && !headers['X-CSRFToken']) {
      headers['X-CSRFToken'] = csrfToken;
    }

    const config = {
      ...options,
      headers,
      credentials: 'include'
    };

    try {
      const response = await fetch(endpoint, config);
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || data.detail || `Request failed with status ${response.status}`);
      }
      return data;
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      throw err;
    }
  },

  // Auth Endpoints
  async getMe() {
    return this.request('/api/auth/me/');
  },

  async login(username_or_email, password) {
    return this.request('/api/auth/login/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username_or_email, password })
    });
  },

  async demoLogin(username) {
    return this.request('/api/auth/demo-login/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username })
    });
  },

  async register(username, email, password, display_name, bio) {
    return this.request('/api/auth/register/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password, display_name, bio })
    });
  },

  async logout() {
    return this.request('/api/auth/logout/', {
      method: 'POST'
    });
  },

  // User & Profile
  async getUser(username) {
    return this.request(`/api/users/${encodeURIComponent(username)}/`);
  },

  async updateProfile(formData) {
    // formData can be FormData instance or JSON
    const options = { method: 'PATCH' };
    if (formData instanceof FormData) {
      options.body = formData;
    } else {
      options.headers = { 'Content-Type': 'application/json' };
      options.body = JSON.stringify(formData);
    }
    return this.request('/api/users/me/', options);
  },

  async toggleFollow(username) {
    return this.request(`/api/users/${encodeURIComponent(username)}/follow/`, {
      method: 'POST'
    });
  },

  async getFollowers(username) {
    return this.request(`/api/users/${encodeURIComponent(username)}/followers/`);
  },

  async getFollowing(username) {
    return this.request(`/api/users/${encodeURIComponent(username)}/following/`);
  },

  async getSuggestedUsers() {
    return this.request('/api/users/suggested/');
  },

  // Posts & Feed
  async getPosts(params = {}) {
    const url = new URL('/api/posts/', window.location.origin);
    Object.keys(params).forEach(k => {
      if (params[k] !== undefined && params[k] !== null && params[k] !== '') {
        url.searchParams.append(k, params[k]);
      }
    });
    return this.request(url.pathname + url.search);
  },

  async getPost(postId) {
    return this.request(`/api/posts/${postId}/`);
  },

  async createPost(formData) {
    const options = { method: 'POST' };
    if (formData instanceof FormData) {
      options.body = formData;
    } else {
      options.headers = { 'Content-Type': 'application/json' };
      options.body = JSON.stringify(formData);
    }
    return this.request('/api/posts/', options);
  },

  async updatePost(postId, content) {
    return this.request(`/api/posts/${postId}/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content })
    });
  },

  async deletePost(postId) {
    return this.request(`/api/posts/${postId}/`, {
      method: 'DELETE'
    });
  },

  async toggleLike(postId) {
    return this.request(`/api/posts/${postId}/like/`, {
      method: 'POST'
    });
  },

  async toggleSave(postId) {
    return this.request(`/api/posts/${postId}/save/`, {
      method: 'POST'
    });
  },

  // Comments
  async getComments(postId) {
    return this.request(`/api/posts/${postId}/comments/`);
  },

  async addComment(postId, content) {
    return this.request(`/api/posts/${postId}/comments/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content })
    });
  },

  async deleteComment(commentId) {
    return this.request(`/api/comments/${commentId}/`, {
      method: 'DELETE'
    });
  },

  // Notifications
  async getNotifications() {
    return this.request('/api/notifications/');
  },

  async markNotificationsRead(notificationId = null) {
    return this.request('/api/notifications/mark-read/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notification_id: notificationId })
    });
  },

  // Settings
  async changePassword(oldPassword, newPassword) {
    return this.request('/api/settings/password/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ old_password: oldPassword, new_password: newPassword })
    });
  }
};

window.API = API;
