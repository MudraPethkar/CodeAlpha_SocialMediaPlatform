/**
 * NOOK Social Media Platform - Application Logic
 * Pure Vanilla JavaScript SPA Controller
 */

// Global State
const State = {
  currentUser: null,
  currentRoute: 'feed', // 'feed', 'explore', 'notifications', 'saved', 'profile', 'settings', 'post-detail'
  feedType: 'for_you', // 'for_you' or 'following'
  currentProfileUsername: null,
  currentPostDetailId: null,
  posts: [],
  page: 1,
  hasNextPage: false,
  isLoading: false,
  theme: localStorage.getItem('nook_theme') || 'light',
  unreadNotifications: 0
};

// Utility Helpers
function timeAgo(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);

  if (seconds < 60) return 'Just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function formatPostText(text) {
  if (!text) return '';
  const escaped = escapeHtml(text);
  // Highlight hashtags
  return escaped.replace(/#(\w+)/g, '<span class="post-hashtag" onclick="App.searchTag(\'$1\')">#$1</span>');
}

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `nook-toast ${type}`;
  toast.innerHTML = `
    <div style="font-size: 1.2rem;">${type === 'success' ? '✨' : '⚠️'}</div>
    <div>${escapeHtml(message)}</div>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(15px)';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

// Main Application Object
const App = {
  async init() {
    this.applyTheme(State.theme);
    this.bindEvents();
    await this.checkAuth();
    this.handleInitialRoute();
    this.loadSuggestedUsers();
  },

  // Theme Management
  applyTheme(theme) {
    State.theme = theme;
    localStorage.setItem('nook_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
    const themeBtn = document.getElementById('theme-toggle-btn');
    const mobileThemeBtn = document.getElementById('mobile-theme-btn');
    const label = theme === 'dark' ? '☀️ Light' : '🌙 Dark';
    if (themeBtn) themeBtn.textContent = label;
    if (mobileThemeBtn) mobileThemeBtn.textContent = label;
  },

  toggleTheme() {
    const nextTheme = State.theme === 'dark' ? 'light' : 'dark';
    this.applyTheme(nextTheme);
    showToast(`Switched to ${nextTheme} mode!`, 'success');
  },

  // Auth Management
  async checkAuth() {
    try {
      const res = await API.getMe();
      if (res.authenticated && res.user) {
        State.currentUser = res.user;
        State.unreadNotifications = res.unread_notifications || 0;
        this.updateUserUI();
      } else {
        State.currentUser = null;
        this.updateUserUI();
      }
    } catch (err) {
      console.warn('Auth check error:', err);
      State.currentUser = null;
      this.updateUserUI();
    }
  },

  updateUserUI() {
    const user = State.currentUser;
    const sidebarUser = document.getElementById('sidebar-user-block');
    const sidebarAvatar = document.getElementById('sidebar-user-avatar');
    const sidebarName = document.getElementById('sidebar-user-name');
    const sidebarHandle = document.getElementById('sidebar-user-handle');
    const composeAvatar = document.getElementById('compose-avatar');
    const composeCard = document.getElementById('compose-card');
    const notifBadge = document.getElementById('nav-notif-badge');
    const guestBanner = document.getElementById('guest-welcome-banner');

    if (notifBadge) {
      if (State.unreadNotifications > 0) {
        notifBadge.style.display = 'inline-block';
        notifBadge.textContent = State.unreadNotifications;
      } else {
        notifBadge.style.display = 'none';
      }
    }

    if (user) {
      if (sidebarUser) sidebarUser.style.display = 'flex';
      if (guestBanner) guestBanner.style.display = 'none';
      if (composeCard) composeCard.style.display = 'block';

      if (sidebarAvatar) sidebarAvatar.src = user.avatar_url;
      if (sidebarName) sidebarName.textContent = user.display_name;
      if (sidebarHandle) sidebarHandle.textContent = `@${user.username}`;
      if (composeAvatar) composeAvatar.src = user.avatar_url;
    } else {
      if (sidebarUser) sidebarUser.style.display = 'none';
      if (guestBanner) guestBanner.style.display = 'block';
      if (composeCard) composeCard.style.display = 'none';
    }
  },

  // Navigation & Routing
  navigate(route, param = null) {
    State.currentRoute = route;
    if (route === 'profile') State.currentProfileUsername = param;
    if (route === 'post-detail') State.currentPostDetailId = param;

    // Update active nav icons
    document.querySelectorAll('.nav-item').forEach(el => {
      if (el.dataset.route === route) {
        el.classList.add('active');
      } else {
        el.classList.remove('active');
      }
    });

    document.querySelectorAll('.mobile-nav-btn').forEach(el => {
      if (el.dataset.route === route) {
        el.classList.add('active');
      } else {
        el.classList.remove('active');
      }
    });

    // Render corresponding screen
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.renderCurrentView();
  },

  handleInitialRoute() {
    this.navigate('feed');
  },

  renderCurrentView() {
    const feedView = document.getElementById('view-feed');
    const profileView = document.getElementById('view-profile');
    const notificationsView = document.getElementById('view-notifications');
    const settingsView = document.getElementById('view-settings');
    const exploreView = document.getElementById('view-explore');
    const postDetailView = document.getElementById('view-post-detail');

    // Hide all
    [feedView, profileView, notificationsView, settingsView, exploreView, postDetailView].forEach(v => {
      if (v) v.style.display = 'none';
    });

    switch (State.currentRoute) {
      case 'feed':
        if (feedView) feedView.style.display = 'block';
        this.loadFeed(true);
        break;
      case 'explore':
        if (exploreView) exploreView.style.display = 'block';
        this.loadExplore();
        break;
      case 'notifications':
        if (notificationsView) notificationsView.style.display = 'block';
        this.loadNotifications();
        break;
      case 'saved':
        if (feedView) feedView.style.display = 'block';
        this.loadSavedPosts();
        break;
      case 'profile':
        if (profileView) profileView.style.display = 'block';
        this.loadProfile(State.currentProfileUsername || (State.currentUser ? State.currentUser.username : null));
        break;
      case 'settings':
        if (settingsView) settingsView.style.display = 'block';
        this.renderSettings();
        break;
      case 'post-detail':
        if (postDetailView) postDetailView.style.display = 'block';
        this.loadPostDetail(State.currentPostDetailId);
        break;
      default:
        if (feedView) feedView.style.display = 'block';
        this.loadFeed(true);
    }
  },

  // Feed & Posts
  async setFeedType(type) {
    if (type === 'following' && !State.currentUser) {
      this.openAuthModal('login');
      showToast('Please sign in to view your Following feed!', 'error');
      return;
    }
    State.feedType = type;
    document.querySelectorAll('.feed-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.feed === type);
    });
    await this.loadFeed(true);
  },

  async loadFeed(reset = false) {
    if (reset) {
      State.page = 1;
      State.posts = [];
    }
    State.isLoading = true;
    const postsContainer = document.getElementById('posts-container');
    const loadMoreBox = document.getElementById('feed-load-more');

    if (reset && postsContainer) {
      postsContainer.innerHTML = `
        <div style="text-align: center; padding: 40px; color: var(--text-muted);">
          <div style="font-size: 2rem; margin-bottom: 8px;">🌸</div>
          <div>Loading cozy posts...</div>
        </div>
      `;
    }

    try {
      const data = await API.getPosts({
        feed: State.feedType,
        page: State.page,
        page_size: 10
      });

      State.hasNextPage = data.has_next;
      if (reset) {
        State.posts = data.results;
      } else {
        State.posts = State.posts.concat(data.results);
      }

      this.renderPosts(postsContainer, State.posts);

      if (loadMoreBox) {
        loadMoreBox.style.display = State.hasNextPage ? 'block' : 'none';
      }
    } catch (err) {
      if (postsContainer) {
        postsContainer.innerHTML = `
          <div style="text-align: center; padding: 40px; color: var(--color-like);">
            Failed to load posts. Please try again.
          </div>
        `;
      }
    } finally {
      State.isLoading = false;
    }
  },

  async loadMorePosts() {
    if (State.isLoading || !State.hasNextPage) return;
    State.page += 1;
    await this.loadFeed(false);
  },

  renderPosts(container, posts) {
    if (!container) return;
    if (!posts || posts.length === 0) {
      container.innerHTML = `
        <div class="post-card" style="text-align: center; padding: 48px 24px;">
          <div style="font-size: 2.8rem; margin-bottom: 12px;">🌿</div>
          <h3 style="font-size: 1.2rem; font-weight: 800; margin-bottom: 6px;">No posts here yet</h3>
          <p style="color: var(--text-muted); font-size: 0.95rem; max-width: 380px; margin: 0 auto 18px;">
            ${State.feedType === 'following' ? "You aren't following anyone with posts yet, or they haven't posted recently." : 'Be the first one to share a cozy moment with the community!'}
          </p>
          ${State.currentUser ? '<button class="sidebar-cta-btn" style="width: auto; margin: 0 auto;" onclick="document.getElementById(\'compose-textarea\').focus()">Create a Post</button>' : ''}
        </div>
      `;
      return;
    }

    container.innerHTML = posts.map(post => this.renderPostCardHtml(post)).join('');
  },

  renderPostCardHtml(post) {
    const isLiked = post.is_liked;
    const isSaved = post.is_saved;
    const isAuthor = post.is_author;

    return `
      <article class="post-card" id="post-card-${post.id}">
        <header class="post-header">
          <div class="post-author-link" onclick="App.navigate('profile', '${escapeHtml(post.author.username)}')">
            <img class="post-avatar" src="${escapeHtml(post.author.avatar_url)}" alt="${escapeHtml(post.author.display_name)}" />
            <div class="post-author-info">
              <div class="post-author-name">
                ${escapeHtml(post.author.display_name)}
                ${post.author.username === 'nook_team' ? '<span class="post-badge-highlight">Official</span>' : ''}
              </div>
              <div class="post-author-meta">
                <span>@${escapeHtml(post.author.username)}</span>
                <span class="post-dot-divider">•</span>
                <time title="${post.created_at}">${timeAgo(post.created_at)}</time>
              </div>
            </div>
          </div>

          <div class="post-menu-wrap">
            <button class="post-menu-btn" onclick="App.togglePostMenu(${post.id}, event)" aria-label="More options">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
            </button>
            <div class="post-dropdown" id="post-dropdown-${post.id}">
              <button class="post-dropdown-item" onclick="App.copyPostLink(${post.id})">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                Copy Link
              </button>
              ${isAuthor ? `
                <button class="post-dropdown-item" onclick="App.openEditPostModal(${post.id})">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                  Edit Post
                </button>
                <button class="post-dropdown-item danger" onclick="App.deletePost(${post.id})">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                  Delete Post
                </button>
              ` : ''}
            </div>
          </div>
        </header>

        <div class="post-body">
          <div class="post-text">${formatPostText(post.content)}</div>
          ${post.image_url ? `
            <div class="post-media" onclick="App.openImageLightbox('${escapeHtml(post.image_url)}')">
              <img src="${escapeHtml(post.image_url)}" alt="Post image" loading="lazy" />
            </div>
          ` : ''}
        </div>

        <footer class="post-actions">
          <button class="post-action-btn btn-like ${isLiked ? 'liked' : ''}" id="like-btn-${post.id}" onclick="App.toggleLike(${post.id})">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
            <span id="likes-count-${post.id}">${post.likes_count}</span>
          </button>

          <button class="post-action-btn btn-comment" onclick="App.toggleComments(${post.id})">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
            </svg>
            <span id="comments-count-${post.id}">${post.comments_count}</span>
          </button>

          <button class="post-action-btn btn-save ${isSaved ? 'saved' : ''}" id="save-btn-${post.id}" onclick="App.toggleSave(${post.id})">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
            <span>${isSaved ? 'Saved' : 'Save'}</span>
          </button>

          <button class="post-action-btn btn-share" onclick="App.copyPostLink(${post.id})">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
              <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
            </svg>
            <span>Share</span>
          </button>
        </footer>

        <!-- Inline Comments Section -->
        <section class="post-comments-section" id="comments-sec-${post.id}">
          <div class="comments-list" id="comments-list-${post.id}">
            ${post.recent_comments ? post.recent_comments.map(c => this.renderCommentItemHtml(c)).join('') : ''}
          </div>

          <form class="comment-form" onsubmit="App.submitComment(${post.id}, event)">
            <input type="text" class="comment-input" id="comment-input-${post.id}" placeholder="Write a cozy comment..." required autocomplete="off" />
            <button type="submit" class="comment-submit-btn">Reply</button>
          </form>
        </section>
      </article>
    `;
  },

  renderCommentItemHtml(comment) {
    const isAuthor = comment.is_author;
    return `
      <div class="comment-item" id="comment-item-${comment.id}">
        <img class="comment-avatar" src="${escapeHtml(comment.author.avatar_url)}" alt="${escapeHtml(comment.author.display_name)}" />
        <div class="comment-bubble">
          <div class="comment-author-line">
            <span class="comment-author-name" onclick="App.navigate('profile', '${escapeHtml(comment.author.username)}')">
              ${escapeHtml(comment.author.display_name)}
            </span>
            <span class="comment-time">${timeAgo(comment.created_at)}</span>
          </div>
          <div class="comment-text">${escapeHtml(comment.content)}</div>
          ${isAuthor ? `
            <a class="comment-delete-btn" onclick="App.deleteComment(${comment.id}, ${comment.post_id})">Delete</a>
          ` : ''}
        </div>
      </div>
    `;
  },

  // Post Actions
  async toggleLike(postId) {
    if (!State.currentUser) {
      this.openAuthModal('login');
      showToast('Please sign in to like posts!', 'error');
      return;
    }

    const btn = document.getElementById(`like-btn-${postId}`);
    const counter = document.getElementById(`likes-count-${postId}`);
    if (!btn || !counter) return;

    // Optimistic UI update
    const currentlyLiked = btn.classList.contains('liked');
    let currentCount = parseInt(counter.textContent) || 0;

    btn.classList.toggle('liked', !currentlyLiked);
    counter.textContent = currentlyLiked ? Math.max(0, currentCount - 1) : currentCount + 1;

    try {
      const res = await API.toggleLike(postId);
      btn.classList.toggle('liked', res.is_liked);
      counter.textContent = res.likes_count;
    } catch (err) {
      // Revert on error
      btn.classList.toggle('liked', currentlyLiked);
      counter.textContent = currentCount;
      showToast(err.message, 'error');
    }
  },

  async toggleSave(postId) {
    if (!State.currentUser) {
      this.openAuthModal('login');
      showToast('Please sign in to save posts!', 'error');
      return;
    }

    const btn = document.getElementById(`save-btn-${postId}`);
    if (!btn) return;
    const currentlySaved = btn.classList.contains('saved');

    try {
      const res = await API.toggleSave(postId);
      btn.classList.toggle('saved', res.is_saved);
      btn.querySelector('span').textContent = res.is_saved ? 'Saved' : 'Save';
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  toggleComments(postId) {
    const sec = document.getElementById(`comments-sec-${postId}`);
    if (!sec) return;
    const isOpen = sec.classList.toggle('open');
    if (isOpen) {
      this.refreshComments(postId);
      const input = document.getElementById(`comment-input-${postId}`);
      if (input) input.focus();
    }
  },

  async refreshComments(postId) {
    const list = document.getElementById(`comments-list-${postId}`);
    if (!list) return;

    try {
      const res = await API.getComments(postId);
      if (res.results.length === 0) {
        list.innerHTML = `<div style="font-size: 0.85rem; color: var(--text-light); text-align: center; padding: 6px;">No comments yet. Start the conversation!</div>`;
      } else {
        list.innerHTML = res.results.map(c => this.renderCommentItemHtml(c)).join('');
      }
    } catch (err) {
      console.error(err);
    }
  },

  async submitComment(postId, event) {
    event.preventDefault();
    if (!State.currentUser) {
      this.openAuthModal('login');
      showToast('Please sign in to leave a comment!', 'error');
      return;
    }

    const input = document.getElementById(`comment-input-${postId}`);
    const content = input.value.trim();
    if (!content) return;

    try {
      const res = await API.addComment(postId, content);
      input.value = '';
      this.refreshComments(postId);
      const countEl = document.getElementById(`comments-count-${postId}`);
      if (countEl) countEl.textContent = res.comments_count;
      showToast('Comment posted!', 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  async deleteComment(commentId, postId) {
    if (!confirm('Are you sure you want to delete this comment?')) return;
    try {
      const res = await API.deleteComment(commentId);
      const item = document.getElementById(`comment-item-${commentId}`);
      if (item) item.remove();
      const countEl = document.getElementById(`comments-count-${postId}`);
      if (countEl) countEl.textContent = res.comments_count;
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  togglePostMenu(postId, event) {
    event.stopPropagation();
    // Close other dropdowns
    document.querySelectorAll('.post-dropdown').forEach(d => {
      if (d.id !== `post-dropdown-${postId}`) d.classList.remove('show');
    });
    const dropdown = document.getElementById(`post-dropdown-${postId}`);
    if (dropdown) dropdown.classList.toggle('show');
  },

  copyPostLink(postId) {
    const url = `${window.location.origin}/#post-${postId}`;
    navigator.clipboard.writeText(url).then(() => {
      showToast('Link copied to clipboard!', 'success');
    }).catch(() => {
      showToast('URL: ' + url, 'success');
    });
    document.querySelectorAll('.post-dropdown').forEach(d => d.classList.remove('show'));
  },

  async deletePost(postId) {
    if (!confirm('Are you sure you want to delete this post? This action cannot be undone.')) return;
    try {
      const res = await API.deletePost(postId);
      const card = document.getElementById(`post-card-${postId}`);
      if (card) {
        card.style.opacity = '0';
        card.style.transform = 'scale(0.95)';
        setTimeout(() => card.remove(), 250);
      }
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Compose Post
  async submitNewPost(event) {
    event.preventDefault();
    if (!State.currentUser) {
      this.openAuthModal('login');
      return;
    }

    const textarea = document.getElementById('compose-textarea');
    const imageInput = document.getElementById('compose-file-input');
    const imageUrlInput = document.getElementById('compose-url-input');
    const submitBtn = document.getElementById('btn-submit-post');

    const content = textarea.value.trim();
    const hasImageFile = imageInput && imageInput.files && imageInput.files.length > 0;
    const imageUrl = imageUrlInput ? imageUrlInput.value.trim() : '';

    if (!content && !hasImageFile && !imageUrl) {
      showToast('Please write something or attach an image!', 'error');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Publishing...';

    try {
      const formData = new FormData();
      formData.append('content', content);
      if (hasImageFile) {
        formData.append('image', imageInput.files[0]);
      }
      if (imageUrl) {
        formData.append('image_url', imageUrl);
      }

      const res = await API.createPost(formData);
      showToast('Posted to NOOK!', 'success');

      // Reset compose box
      textarea.value = '';
      if (imageInput) imageInput.value = '';
      if (imageUrlInput) imageUrlInput.value = '';
      this.clearComposeImage();
      this.updateCharCount();

      // Prepend post to feed
      State.posts.unshift(res.post);
      const postsContainer = document.getElementById('posts-container');
      if (postsContainer) {
        this.renderPosts(postsContainer, State.posts);
      }
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `<span>Post</span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`;
    }
  },

  handleImageSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    const previewWrap = document.getElementById('compose-preview-wrap');
    const previewImg = document.getElementById('compose-preview-img');

    const reader = new FileReader();
    reader.onload = e => {
      if (previewImg && previewWrap) {
        previewImg.src = e.target.result;
        previewWrap.style.display = 'block';
      }
    };
    reader.readAsDataURL(file);
  },

  clearComposeImage() {
    const previewWrap = document.getElementById('compose-preview-wrap');
    const imageInput = document.getElementById('compose-file-input');
    const imageUrlInput = document.getElementById('compose-url-input');

    if (previewWrap) previewWrap.style.display = 'none';
    if (imageInput) imageInput.value = '';
    if (imageUrlInput) imageUrlInput.value = '';
  },

  updateCharCount() {
    const textarea = document.getElementById('compose-textarea');
    const counter = document.getElementById('compose-char-counter');
    if (!textarea || !counter) return;

    const remaining = 500 - textarea.value.length;
    counter.textContent = remaining;

    counter.className = 'compose-char-counter';
    if (remaining < 50) counter.classList.add('warning');
    if (remaining < 15) counter.classList.add('danger');
  },

  // Edit Post Modal
  openEditPostModal(postId) {
    const post = State.posts.find(p => p.id === postId);
    if (!post) return;

    document.getElementById('edit-post-id').value = postId;
    document.getElementById('edit-post-content').value = post.content;
    document.getElementById('modal-edit-post').classList.add('show');
    document.querySelectorAll('.post-dropdown').forEach(d => d.classList.remove('show'));
  },

  async submitEditPost(event) {
    event.preventDefault();
    const postId = document.getElementById('edit-post-id').value;
    const content = document.getElementById('edit-post-content').value.trim();

    try {
      const res = await API.updatePost(postId, content);
      showToast('Post updated successfully!', 'success');
      this.closeModal('modal-edit-post');

      // Update in local state & DOM
      const post = State.posts.find(p => p.id === parseInt(postId));
      if (post) post.content = res.post.content;

      const postEl = document.querySelector(`#post-card-${postId} .post-text`);
      if (postEl) postEl.innerHTML = formatPostText(content);
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Profile Page
  async loadProfile(username) {
    if (!username) {
      this.openAuthModal('login');
      return;
    }

    const container = document.getElementById('profile-content-container');
    if (!container) return;

    container.innerHTML = `<div style="text-align: center; padding: 60px; color: var(--text-muted);">Loading profile @${escapeHtml(username)}...</div>`;

    try {
      const profile = await API.getUser(username);
      container.innerHTML = `
        <div class="profile-card">
          <div class="profile-banner"></div>
          <div class="profile-header-content">
            <div class="profile-avatar-row">
              <img class="profile-main-avatar" src="${escapeHtml(profile.avatar_url)}" alt="${escapeHtml(profile.display_name)}" />
              <div class="profile-actions-bar">
                ${profile.is_self ? `
                  <button class="btn-profile-primary" onclick="App.openEditProfileModal()">Edit Profile</button>
                ` : `
                  <button class="btn-follow-toggle ${profile.is_following ? 'following' : ''}" id="profile-follow-btn" onclick="App.toggleProfileFollow('${escapeHtml(profile.username)}')">
                    ${profile.is_following ? 'Following' : 'Follow'}
                  </button>
                `}
              </div>
            </div>

            <div class="profile-names-block">
              <h2 class="profile-display-name">${escapeHtml(profile.display_name)}</h2>
              <div class="profile-username-handle">@${escapeHtml(profile.username)}</div>
            </div>

            <p class="profile-bio-text">${escapeHtml(profile.bio || 'No bio yet. Still wandering through the cozy woods.')}</p>

            <div class="profile-stats-row">
              <div class="profile-stat-box" onclick="App.switchProfileTab('posts', '${escapeHtml(profile.username)}')">
                <span class="profile-stat-num">${profile.posts_count}</span>
                <span class="profile-stat-label">Posts</span>
              </div>
              <div class="profile-stat-box" onclick="App.showFollowersModal('${escapeHtml(profile.username)}')">
                <span class="profile-stat-num" id="profile-followers-count">${profile.followers_count}</span>
                <span class="profile-stat-label">Followers</span>
              </div>
              <div class="profile-stat-box" onclick="App.showFollowingModal('${escapeHtml(profile.username)}')">
                <span class="profile-stat-num">${profile.following_count}</span>
                <span class="profile-stat-label">Following</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Profile Tabs -->
        <div class="stream-header" style="margin-top: 10px;">
          <div class="feed-tabs">
            <button class="feed-tab-btn active" id="profile-tab-posts" onclick="App.switchProfileTab('posts', '${escapeHtml(profile.username)}')">Posts</button>
            <button class="feed-tab-btn" id="profile-tab-liked" onclick="App.switchProfileTab('liked', '${escapeHtml(profile.username)}')">Liked</button>
            ${profile.is_self ? `<button class="feed-tab-btn" id="profile-tab-saved" onclick="App.switchProfileTab('saved', '${escapeHtml(profile.username)}')">Saved</button>` : ''}
          </div>
        </div>

        <div class="posts-feed" id="profile-posts-container" style="margin-top: 20px;"></div>
      `;

      // Load initial profile posts
      this.switchProfileTab('posts', username);
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 60px; color: var(--color-like);">User not found.</div>`;
    }
  },

  async switchProfileTab(tab, username) {
    document.querySelectorAll('.feed-tabs .feed-tab-btn').forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.getElementById(`profile-tab-${tab}`);
    if (activeBtn) activeBtn.classList.add('active');

    const container = document.getElementById('profile-posts-container');
    if (!container) return;

    container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--text-muted);">Loading ${tab}...</div>`;

    try {
      let params = {};
      if (tab === 'posts') params.author = username;
      if (tab === 'liked') params.liked = 'true';
      if (tab === 'saved') params.saved = 'true';

      const data = await API.getPosts(params);
      this.renderPosts(container, data.results);
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--color-like);">Failed to load ${tab}.</div>`;
    }
  },

  async toggleProfileFollow(username) {
    if (!State.currentUser) {
      this.openAuthModal('login');
      return;
    }

    const btn = document.getElementById('profile-follow-btn');
    const followersEl = document.getElementById('profile-followers-count');

    try {
      const res = await API.toggleFollow(username);
      if (btn) {
        btn.classList.toggle('following', res.is_following);
        btn.textContent = res.is_following ? 'Following' : 'Follow';
      }
      if (followersEl) {
        followersEl.textContent = res.followers_count;
      }
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Edit Profile Modal
  openEditProfileModal() {
    if (!State.currentUser) return;
    document.getElementById('edit-display-name').value = State.currentUser.display_name;
    document.getElementById('edit-bio').value = State.currentUser.bio || '';
    document.getElementById('edit-avatar-url').value = State.currentUser.avatar_url || '';
    document.getElementById('modal-edit-profile').classList.add('show');
  },

  async submitEditProfile(event) {
    event.preventDefault();
    const displayName = document.getElementById('edit-display-name').value.trim();
    const bio = document.getElementById('edit-bio').value.trim();
    const avatarUrl = document.getElementById('edit-avatar-url').value.trim();
    const fileInput = document.getElementById('edit-avatar-file');

    try {
      const formData = new FormData();
      formData.append('display_name', displayName);
      formData.append('bio', bio);
      if (avatarUrl) formData.append('avatar_url', avatarUrl);
      if (fileInput && fileInput.files && fileInput.files[0]) {
        formData.append('avatar', fileInput.files[0]);
      }

      const res = await API.updateProfile(formData);
      State.currentUser = res.user;
      this.updateUserUI();
      this.closeModal('modal-edit-profile');
      showToast('Profile updated!', 'success');
      this.loadProfile(res.user.username);
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Explore & Discover
  async loadExplore(query = '') {
    const exploreContainer = document.getElementById('explore-posts-container');
    if (!exploreContainer) return;

    exploreContainer.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--text-muted);">Exploring NOOK...</div>`;

    try {
      const data = await API.getPosts({ search: query, page_size: 15 });
      this.renderPosts(exploreContainer, data.results);
    } catch (err) {
      exploreContainer.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--color-like);">Could not load explore posts.</div>`;
    }
  },

  searchTag(tag) {
    this.navigate('explore');
    const searchInput = document.getElementById('main-search-input');
    if (searchInput) searchInput.value = `#${tag}`;
    this.loadExplore(tag);
  },

  handleSearchInput(event) {
    const query = event.target.value.trim();
    if (State.currentRoute !== 'explore') {
      this.navigate('explore');
    }
    clearTimeout(this._searchTimer);
    this._searchTimer = setTimeout(() => {
      this.loadExplore(query);
    }, 350);
  },

  // Saved Posts Screen
  async loadSavedPosts() {
    if (!State.currentUser) {
      this.openAuthModal('login');
      return;
    }
    const container = document.getElementById('posts-container');
    if (!container) return;
    container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--text-muted);">Loading your saved bookmarks...</div>`;

    try {
      const data = await API.getPosts({ saved: 'true' });
      this.renderPosts(container, data.results);
      const loadMoreBox = document.getElementById('feed-load-more');
      if (loadMoreBox) loadMoreBox.style.display = 'none';
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--color-like);">Failed to load bookmarks.</div>`;
    }
  },

  // Notifications
  async loadNotifications() {
    if (!State.currentUser) {
      this.openAuthModal('login');
      return;
    }

    const container = document.getElementById('notifications-list-container');
    if (!container) return;

    container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--text-muted);">Fetching your notifications...</div>`;

    try {
      const data = await API.getNotifications();
      if (data.results.length === 0) {
        container.innerHTML = `
          <div class="post-card" style="text-align: center; padding: 40px;">
            <div style="font-size: 2.2rem; margin-bottom: 8px;">💌</div>
            <h3 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 4px;">All caught up!</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">You don't have any notifications right now.</p>
          </div>
        `;
        return;
      }

      container.innerHTML = data.results.map(n => {
        let iconHtml = '';
        let desc = '';
        if (n.type === 'like') {
          iconHtml = `<div class="notif-type-icon notif-like"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>`;
          desc = `liked your post: <em>"${escapeHtml(n.post_preview || '')}"</em>`;
        } else if (n.type === 'comment') {
          iconHtml = `<div class="notif-type-icon notif-comment"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>`;
          desc = `commented on your post: <em>"${escapeHtml(n.post_preview || '')}"</em>`;
        } else if (n.type === 'follow') {
          iconHtml = `<div class="notif-type-icon notif-follow"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg></div>`;
          desc = `started following your nook!`;
        }

        return `
          <div class="notification-item ${!n.is_read ? 'unread' : ''}" onclick="App.handleNotifClick(${n.id}, ${n.post_id || 'null'})">
            ${iconHtml}
            <img style="width: 38px; height: 38px; border-radius: 50%; object-fit: cover;" src="${escapeHtml(n.actor.avatar_url)}" alt="${escapeHtml(n.actor.display_name)}" />
            <div class="notif-content-wrap">
              <div class="notif-text">
                <strong>${escapeHtml(n.actor.display_name)}</strong> (@${escapeHtml(n.actor.username)}) ${desc}
              </div>
              <div class="notif-time">${timeAgo(n.created_at)}</div>
            </div>
          </div>
        `;
      }).join('');

      // Update badge
      State.unreadNotifications = 0;
      this.updateUserUI();
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--color-like);">Could not load notifications.</div>`;
    }
  },

  async handleNotifClick(notifId, postId) {
    try {
      await API.markNotificationsRead(notifId);
    } catch (e) {}
    if (postId) {
      this.navigate('post-detail', postId);
    }
  },

  async markAllNotificationsRead() {
    try {
      await API.markNotificationsRead();
      showToast('All notifications marked as read!', 'success');
      this.loadNotifications();
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Post Detail Screen
  async loadPostDetail(postId) {
    const container = document.getElementById('post-detail-container');
    if (!container) return;

    container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--text-muted);">Loading conversation...</div>`;

    try {
      const post = await API.getPost(postId);
      container.innerHTML = `
        <button class="nav-item" style="width: fit-content; margin-bottom: 16px; padding: 8px 16px;" onclick="App.navigate('feed')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
          Back to Feed
        </button>
        ${this.renderPostCardHtml(post)}
      `;

      // Auto open comment section
      setTimeout(() => {
        const sec = document.getElementById(`comments-sec-${post.id}`);
        if (sec) sec.classList.add('open');
      }, 50);
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--color-like);">Post not found or deleted.</div>`;
    }
  },

  // Suggested Users
  async loadSuggestedUsers() {
    const list = document.getElementById('suggested-users-list');
    if (!list) return;

    try {
      const res = await API.getSuggestedUsers();
      if (res.results.length === 0) {
        list.innerHTML = `<div style="font-size: 0.85rem; color: var(--text-light); text-align: center; padding: 10px;">You are all connected!</div>`;
        return;
      }

      list.innerHTML = res.results.map(u => `
        <div class="suggested-user-item">
          <div class="suggested-user-left" onclick="App.navigate('profile', '${escapeHtml(u.username)}')">
            <img class="suggested-user-avatar" src="${escapeHtml(u.avatar_url)}" alt="${escapeHtml(u.display_name)}" />
            <div class="suggested-user-meta">
              <div class="suggested-user-name">${escapeHtml(u.display_name)}</div>
              <div class="suggested-user-handle">@${escapeHtml(u.username)}</div>
            </div>
          </div>
          <button class="btn-follow-toggle" id="sug-follow-${u.id}" onclick="App.toggleSuggestedFollow('${escapeHtml(u.username)}', ${u.id})">
            Follow
          </button>
        </div>
      `).join('');
    } catch (err) {
      console.warn('Could not load suggested users:', err);
    }
  },

  async toggleSuggestedFollow(username, userId) {
    if (!State.currentUser) {
      this.openAuthModal('login');
      return;
    }

    const btn = document.getElementById(`sug-follow-${userId}`);
    try {
      const res = await API.toggleFollow(username);
      if (btn) {
        btn.classList.toggle('following', res.is_following);
        btn.textContent = res.is_following ? 'Following' : 'Follow';
      }
      showToast(res.message, 'success');
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Followers & Following Modals
  async showFollowersModal(username) {
    const modal = document.getElementById('modal-users-list');
    const title = document.getElementById('users-list-title');
    const container = document.getElementById('users-list-container');

    title.textContent = `@${username}'s Followers`;
    container.innerHTML = `<div style="text-align: center; padding: 30px; color: var(--text-muted);">Loading...</div>`;
    modal.classList.add('show');

    try {
      const data = await API.getFollowers(username);
      this.renderUsersModalList(container, data.results);
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 30px; color: var(--color-like);">Could not load followers.</div>`;
    }
  },

  async showFollowingModal(username) {
    const modal = document.getElementById('modal-users-list');
    const title = document.getElementById('users-list-title');
    const container = document.getElementById('users-list-container');

    title.textContent = `@${username} is Following`;
    container.innerHTML = `<div style="text-align: center; padding: 30px; color: var(--text-muted);">Loading...</div>`;
    modal.classList.add('show');

    try {
      const data = await API.getFollowing(username);
      this.renderUsersModalList(container, data.results);
    } catch (err) {
      container.innerHTML = `<div style="text-align: center; padding: 30px; color: var(--color-like);">Could not load following.</div>`;
    }
  },

  renderUsersModalList(container, users) {
    if (!users || users.length === 0) {
      container.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--text-muted);">No users found.</div>`;
      return;
    }

    container.innerHTML = users.map(u => `
      <div class="suggested-user-item" style="padding: 8px 0; border-bottom: 1px solid var(--border-subtle);">
        <div class="suggested-user-left" onclick="App.closeModal('modal-users-list'); App.navigate('profile', '${escapeHtml(u.username)}')">
          <img class="suggested-user-avatar" src="${escapeHtml(u.avatar_url)}" alt="${escapeHtml(u.display_name)}" />
          <div class="suggested-user-meta">
            <div class="suggested-user-name">${escapeHtml(u.display_name)}</div>
            <div class="suggested-user-handle">@${escapeHtml(u.username)}</div>
          </div>
        </div>
      </div>
    `).join('');
  },

  // Settings Screen
  renderSettings() {
    const container = document.getElementById('settings-view-container');
    if (!container) return;

    if (!State.currentUser) {
      container.innerHTML = `
        <div class="widget-card" style="text-align: center; padding: 40px;">
          <h3>Please Sign In</h3>
          <p style="color: var(--text-muted); margin: 12px 0 20px;">You need to be logged in to view and edit account settings.</p>
          <button class="btn-profile-primary" onclick="App.openAuthModal('login')">Sign In</button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 20px;">
        <!-- Appearance Settings -->
        <div class="widget-card">
          <h3 class="widget-title">Appearance & Theme</h3>
          <div style="display: flex; align-items: center; justify-content: space-between;">
            <div>
              <div style="font-weight: 700;">Color Mode</div>
              <div style="font-size: 0.85rem; color: var(--text-muted);">Choose between Airy Lilac Light or Midnight Plum Dark mode.</div>
            </div>
            <button class="btn-profile-primary" onclick="App.toggleTheme()">
              Toggle Mode (${State.theme === 'dark' ? 'Dark' : 'Light'})
            </button>
          </div>
        </div>

        <!-- Password Change -->
        <div class="widget-card">
          <h3 class="widget-title">Security & Password</h3>
          <form onsubmit="App.submitChangePassword(event)">
            <div class="form-group">
              <label class="form-label">Current Password</label>
              <input type="password" class="form-input" id="settings-old-pass" required />
            </div>
            <div class="form-group">
              <label class="form-label">New Password (min 6 chars)</label>
              <input type="password" class="form-input" id="settings-new-pass" required minlength="6" />
            </div>
            <button type="submit" class="btn-profile-primary">Update Password</button>
          </form>
        </div>

        <!-- Account Info -->
        <div class="widget-card">
          <h3 class="widget-title">Account Details</h3>
          <div style="font-size: 0.95rem; margin-bottom: 12px;">
            <strong>Username:</strong> @${escapeHtml(State.currentUser.username)}
          </div>
          <div style="font-size: 0.95rem; margin-bottom: 20px;">
            <strong>Email:</strong> ${escapeHtml(State.currentUser.email)}
          </div>
          <button class="btn-profile-primary" style="background: var(--color-like);" onclick="App.logout()">
            Sign Out of NOOK
          </button>
        </div>
      </div>
    `;
  },

  async submitChangePassword(event) {
    event.preventDefault();
    const oldPass = document.getElementById('settings-old-pass').value;
    const newPass = document.getElementById('settings-new-pass').value;

    try {
      const res = await API.changePassword(oldPass, newPass);
      showToast(res.message, 'success');
      document.getElementById('settings-old-pass').value = '';
      document.getElementById('settings-new-pass').value = '';
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Auth Modals & Demo Login
  openAuthModal(mode = 'login') {
    this.switchAuthTab(mode);
    document.getElementById('modal-auth').classList.add('show');
  },

  switchAuthTab(tab) {
    const loginForm = document.getElementById('form-login');
    const registerForm = document.getElementById('form-register');
    const tabLogin = document.getElementById('tab-auth-login');
    const tabRegister = document.getElementById('tab-auth-register');

    if (tab === 'login') {
      loginForm.style.display = 'block';
      registerForm.style.display = 'none';
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
    } else {
      loginForm.style.display = 'none';
      registerForm.style.display = 'block';
      tabLogin.classList.remove('active');
      tabRegister.classList.add('active');
    }
  },

  async submitLogin(event) {
    event.preventDefault();
    const identifier = document.getElementById('login-identifier').value.trim();
    const pass = document.getElementById('login-password').value;

    try {
      const res = await API.login(identifier, pass);
      State.currentUser = res.user;
      this.updateUserUI();
      this.closeModal('modal-auth');
      showToast(`Welcome back, ${res.user.display_name}!`, 'success');
      this.loadSuggestedUsers();
      this.renderCurrentView();
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  async submitRegister(event) {
    event.preventDefault();
    const username = document.getElementById('reg-username').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    const displayName = document.getElementById('reg-display-name').value.trim();
    const bio = document.getElementById('reg-bio').value.trim();

    try {
      const res = await API.register(username, email, password, displayName, bio);
      State.currentUser = res.user;
      this.updateUserUI();
      this.closeModal('modal-auth');
      showToast('Welcome to NOOK! Account created.', 'success');
      this.loadSuggestedUsers();
      this.renderCurrentView();
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  async demoLogin(username) {
    try {
      const res = await API.demoLogin(username);
      State.currentUser = res.user;
      this.updateUserUI();
      this.closeModal('modal-auth');
      showToast(`Logged in as @${res.user.username}!`, 'success');
      this.loadSuggestedUsers();
      this.renderCurrentView();
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  async logout() {
    try {
      await API.logout();
      State.currentUser = null;
      this.updateUserUI();
      showToast('Logged out of NOOK.', 'success');
      this.navigate('feed');
      this.loadSuggestedUsers();
    } catch (err) {
      showToast(err.message, 'error');
    }
  },

  // Story Viewer Modal
  openStory(name, avatar, caption, bgImg) {
    const modal = document.getElementById('modal-story');
    document.getElementById('story-modal-user').textContent = name;
    document.getElementById('story-modal-avatar').src = avatar;
    document.getElementById('story-modal-caption').textContent = caption;
    document.getElementById('story-modal-bg').src = bgImg;

    modal.classList.add('show');

    // Auto close story after 6 seconds
    clearTimeout(this._storyTimer);
    const progressBar = document.getElementById('story-progress-bar');
    if (progressBar) {
      progressBar.style.transition = 'none';
      progressBar.style.width = '0%';
      setTimeout(() => {
        progressBar.style.transition = 'width 6s linear';
        progressBar.style.width = '100%';
      }, 50);
    }

    this._storyTimer = setTimeout(() => {
      this.closeModal('modal-story');
    }, 6000);
  },

  // Image Lightbox
  openImageLightbox(src) {
    const modal = document.getElementById('modal-lightbox');
    const img = document.getElementById('lightbox-img');
    if (img) img.src = src;
    modal.classList.add('show');
  },

  // Modal Helpers
  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('show');
    clearTimeout(this._storyTimer);
  },

  // Global Event Binding
  bindEvents() {
    // Close menus on outside click
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.post-menu-wrap')) {
        document.querySelectorAll('.post-dropdown').forEach(d => d.classList.remove('show'));
      }
    });

    // Close modal on escape
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('show'));
      }
    });
  }
};

window.App = App;

// Bootstrap on DOM loaded
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
